package contorller;

import java.util.HashMap;
import java.util.Map;

public class FrontController {
	
	private Map<String,SubController>map = new HashMap();
	
	public FrontController() {
		System.out.println("FronController()");
		init();
	 }

	private void init() {
		System.out.println("FronController's init()");
		//요청 api
		// user - UserController
		
		map.put("/book", new UserController());
		
	}
	public Map<String,Object> execute(String uri,int ServiceNo,Map<String,Object>parmas){
		
		System.out.println("FrontController's execute");
		SubController controller = map.get(uri);
		return controller.execute(ServiceNo, parmas);
	}
	
	

}
