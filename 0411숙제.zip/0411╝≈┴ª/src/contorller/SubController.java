package contorller;

import java.util.Map;

public  interface SubController {
	
	//1 insert 2 update 3 delete 4 selectall 5 select
	 Map<String,Object> execute(int serviceNo,Map<String,Object> parmas);

}
