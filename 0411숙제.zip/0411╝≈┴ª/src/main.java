import domain.dto.UserDto;
import service.UserServiceImpl;

public class main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		UserServiceImpl serv = new UserServiceImpl();
		
		
//		serv.UserJoin(new UserDto("ha","1234","123","123","123","123"));
		
//		Map<String,Object>  islogin3= serv.login("ha1asd","1234", 2);
//		System.out.println("islogin3 : " + islogin3);
		
//		Map<String,Object>  islogin3= serv.login("ha","1234", 0);
//		System.out.println(islogin3);
//		serv.UserJoin(new UserDto("하상훈","1234","1234","1234","1234","회원"));
//		Map<String,Object> login4 = serv.login("하상훈", "1234", 0);
		
//		serv.logout(16);
		serv.login("없음", "1234", 0);
	
}
}
