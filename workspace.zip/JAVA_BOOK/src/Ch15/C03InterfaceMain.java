package Ch15;

// extends 예약어로는 상속관계 1
// implements 예약어로 다중상속이 가능하다
// extends 먼저 implements 나중에

interface A{}

interface B {}

class C{}

class E extends C implements A,B {}



public class C03InterfaceMain {

}
