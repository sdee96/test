package Ch10;



//1차원 배열: 해당 자료형을 요소단위로 정한다
//2차원 배열 : 1차원 배열을 요소단위로 정한다
public class C03ArrayMain {

	public static void main(String[] args) {
		
		
		int arr[][]= {
				{10,20,30},
				{40,50,60,65,67},
				{70,80,90,96,11,56},
				{100,110,120,15,22,33,44}
		};
		
		
		System.out.println("길이 : " + arr.length); // 행의 길이이며 요소의 개수
		System.out.println("[0]행 열의 길이" + arr[0].length);
		System.out.println("[1]행 열의 길이" + arr[1].length);
		System.out.println("[2]행 열의 길이" + arr[2].length);
		System.out.println("[3]행 열의 길이" + arr[3].length);
		
	}

}
