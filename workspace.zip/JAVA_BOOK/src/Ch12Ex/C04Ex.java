package Ch12Ex;


abstract class Shape{
	abstract void 넓이();
	
}
class Rectangle extends Shape{
	int width;
	int height;
	public Rectangle(int width, int height) {
		super();
		this.width = width;
		this.height = height;
	}
	
	
}
class Triangle extends Shape{
	int height;
	int bottomLine;
	public Triangle(int height, int bottomLine) {
		super();
		this.height = height;
		this.bottomLine = bottomLine;
	}
	
	
}
class Circle extends Shape{
	int radius;
	static final double PI=3.14;
	public Circle(int radius) {
		super();
		this.radius = radius;
	}
	
	
}

public class C04Ex {

	public static void 전체넓이확인(Shape shape){
		
		if(shape instanceof Rectangle) {
			Rectangle rec = (Rectangle)shape;
			
			
		}
	}		
		
	
	public static void main(String[] args) {
		전체넓이확인(new Rectangle(45,45));
		전체넓이확인(new Triangle(100,20));
		전체넓이확인(new Circle(5));
	}
}
