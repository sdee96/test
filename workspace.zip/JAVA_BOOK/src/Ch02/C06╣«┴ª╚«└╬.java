package Ch02;

public class C06문제확인 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	char var= 65;
	
	
	}

}
