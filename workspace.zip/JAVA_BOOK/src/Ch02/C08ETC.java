package Ch02;

public class C08ETC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub                                       
		// 
		System.out.println((int)'ㄱ'); //12593
		System.out.println((int)'ㅏ'); // 12623
		System.out.println((int)'가'); // 44032
		
		System.out.println((int)'a');  // 97
		
		System.out.println(12593+12623);

	}

}
