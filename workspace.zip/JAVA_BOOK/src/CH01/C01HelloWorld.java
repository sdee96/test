package CH01;    // 패키지 구별 코드 

public class C01HelloWorld // 클래스 영역(객체지향 문법)
{

	public static void main(String[] args) // 메서드 영역(절차지향 문법)
	{
		//메서드 종류
		//라이브러리 메서드 : 미리 제공된 메서드
		//사용자 정의 메서드 : 개발자에 의해서 만들어지는 메서드
		//main 메서드 : 최초 실행 메서드
		
		// TODO Auto-generated method stub
		System.out.println("HELLOWORLD");
		

	}

}
