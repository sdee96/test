package Ch07;

import java.util.Scanner;

public class C00whiletest01 {

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		System.out.println("수를 입력");
//		int num = sc.nextInt();
//		if(num<=1) {
//			System.out.println(num + "는 소수가 아님");
//		}
//		int i=2;
//		int cnt=0;
//		while(i<num) {
//			
//			if(num%1==0) {
////				System.out.println("소수 아님");
//				cnt++;  // 총 몇개로 나누어 떨어지는지 확인
//			}
//		if(cnt>0)
//			System.out.println("소수아님");
//		else
//			System.out.println("소수");
//		}
		
		
		Scanner sc = new Scanner(System.in);
//		System.out.println("입력 : ");
//		int num= sc.nextInt();
//		
//		//자리수 구하기
//		int digit = 0;
//		int tmp = num;
//		int result = 0;
//		while(tmp!=0) {
//			digit++;
//			tmp=tmp/10;
//		}
//		System.out.println("자리수  : " + digit);
//		
//		
//		while(num!=0) {
////			System.out.println("num : " + num);
////			System.out.println((num%10));
//			result += (int)((num%10)*(Math.pow(10, digit-1)));
//			digit--;
//			num=num/10;
//		}
//		System.out.println("출력 : " + result);
		
		System.out.println(" 입력 : ");
		int num = sc.nextInt();
		String num_2 = num+"";
		String tmp = "";
		for(int i= num_2.length()-1; i>=0 ; i--) {
			tmp = tmp+num+2.charAt(i);
		}

	}

}
