package Ch07;

import java.util.Scanner;

public class C00whiletest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		
		if(n>m)
		{ int tmp;
			tmp = n;
			n=m;
		}
		int i=n;
		int sum= 0;
		
		while(i<=m) {
			sum+=i;
			i++;
			
			
			
		}
		System.out.printf("%d 부터 %d까지의 합 : %d\n",n,m,sum);
				
	}

}
