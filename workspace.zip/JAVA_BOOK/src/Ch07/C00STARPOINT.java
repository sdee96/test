package Ch07;

import java.util.Scanner;

public class C00STARPOINT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//****
		//****
		//****
		//****
		//행 증가 i 
		//별 찍기 j 
		
		
//		int i  = 0; // 초기 값
//		int j =  0; // 별 
//		while(i<4) {
//			j=0;
//			while(j<4) {
//				System.out.print("*");
//				j++;
//			}
//					
//			
//			System.out.println();
//			i++;
//			
//		}
		
		
		// n 별찍
		Scanner sc = new Scanner(System.in);
//		
//		int i  = 0; // 초기 값
//		int j =  0; // 별 
//		int n = sc.nextInt();
//		while(i<n) {
//			j=0;
//			while(j<4) {
//				System.out.print("*");
//				j++;
//			}
//					
//			
//			System.out.println();
//			i++;
//			
//		}		
		
		 // n 별
//		int n = sc.nextInt();
//		int i  = 0; // 초기 값
//		int j =  0; // 별 
//		while(i<n) {
//			j=0;
//			while(j<=i) {
//				System.out.print("*");
//				j++;
//			}
//					
//			
//			System.out.println();
//			i++;
////			
//		}
//		
		
		
		//삼각형
		
		int i = 0 ;
		int j = 0 ;
		int k = 0 ;
		int n = sc.nextInt();
		while(i<n) {
			//공백
			while(j<=(n-2)-i) {
				System.out.println("  ");
				j++;
			}
			
			k=0;
			while(k<=i*2) {
				System.out.println("*");
				k++;
			}
			System.out.println();
			i++;
			
		}
		
	}

}
