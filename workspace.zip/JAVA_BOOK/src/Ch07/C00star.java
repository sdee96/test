package Ch07;

public class C00star {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// i(행) 0  1 2 3
		// j(공백) 0 1 2 3
		// k(별) 0 1 2 3 4 5 6
		
		//i=0; j = 0 k= 0	
		//i<4;	j<=2-i k<=2*ㅑ
		//i ++	j++  k++;
		
//		int i = 0;
//		int j = 0;
//		int k = 0;
//		while(i<4) {
//			//공백
//			j=0;
//			while(j<=2-i) {
//				System.out.println(" ");
//				
//				j++;
//			}
//			
//			
//			
//			//별
//			k=0;
//			while(k<=2*i) {
//				System.out.println("*");
//					k++;
//			}
//			
//			System.out.println();
//			
//			i++;
//		}
		
		
		//역삼각형
		
		//  i =  0 ;  i < 4  i ++ (행 )
		// 공백 x 0-0 0-1 0-2  
		// 별 0-6 0-4 0-2 0-0
		
		// k < = 6- 2 i; k++
		// j< = i-1 j ++
//		
//		int i =0;
//		int j = 0;
//		int k = 0;
//		
//		while(i<4) {
//			
//			//공백
//			j=0;
//			while(j<=i-1) {
//				
//				System.out.println(" ");
//				j++;
//			}
//			
//			
//			
//			
//			
//			//별
//			k=0;
//			while(k<=6-2*i) {
//				System.out.println("*");
//				k++;
//			}
//			
//			System.out.println();
//			i++;
//		}
//			
//			
//			
		
		// i(행)   j(공백) 	K(별)
		//	0		0-2		0-0
		//	1		0-1		0-2
		//	2		0-0		0-4	
		//	3		x	 	0-6
		// --------------------- (분기처리)
		
		//          ㅓ=0		k=0
		//			j<=2-i	k<=2*i
		//			j++		k++
		
		//	4		0-0		0-4
		//	5		0-1		0-2
		//	6		0-2		0-0
		
		// i=0;				k=0;
		// i<7		j<=i-4	k<=12-2i
		// i ++ 	j++		k++;
			
		
		int i = 0;
		int j= 0;
		int k = 0;
		while(i<7) {
			
			
			if(i<4) {
				//공백
				j=0;
				while(j<=2-i) {
					System.out.println(" ");
					j++;
					
				}
				
				//별				
				k=0;
				while(k<=2*i) {
					System.out.println("*");
					k++;
				}
				
				
				
				
			}
			
			else {

				//공백
				j=0;
				while(j<=i-4) {
					System.out.println(" ");
					j++;
					
				}
				
				//별				
				k=0;
				while(k<=(6*2)-2*i) {
					System.out.println("*");
					k++;
				
			}
			
			
			
			
			
			System.out.println();
			i++;
			
		}

	}

}
