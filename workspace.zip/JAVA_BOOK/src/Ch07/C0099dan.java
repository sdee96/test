package Ch07;

import java.util.Scanner;

public class C0099dan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// n단까지 구구단
		Scanner sc = new Scanner(System.in);
		
		System.out.println("몇단까지 할거임? : ");
		int dan = 2;
		int  i;
		int n = sc.nextInt();
		
		
		while(dan<=n) {
			i=1;
			while(i<=9) {
				System.out.printf("%d x %d = %d\n" ,dan,i,dan*i);
				i++;
			}
			System.out.println("  ");
			dan++;
		}
	}

}
