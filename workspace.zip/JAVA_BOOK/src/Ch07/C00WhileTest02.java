package Ch07;

public class C00WhileTest02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//구구단 출력 2단
//		int  i = 1;
//		while(i<=9) {
//			System.out.println("2 X " + i + " = "+(2*i));
//			i++;
//		}

		
		
		//단수의 반복   : 곱해주는 수의 반복
//		int dan = 2;
//		int  i;
//		while(dan<=9) {
//			i=1;
//			while(i<=9) {
//				System.out.printf("%d x %d = %d\n" ,dan,i,dan*i);
//				i++;
//			}
//			System.out.println("  ");
//			dan++;
//		}
		
		
		// 2 - n
		
//		int dan = 2;
//		int  i;
//		int n = sc.nextInt();
//		while(dan<=n) {
//			i=1;
//			while(i<=9) {
//				System.out.printf("%d x %d = %d\n" ,dan,i,dan*i);
//				i++;
//			}
//			System.out.println("  ");
//			dan++;
//		}
		
		//9 - 2
		
		int dan = 9;
		int  i;
		while(dan>=2) {
			i=9;
			while(i>=1) {
				System.out.printf("%d x %d = %d\n" ,dan,i,dan*i);
				i--;
			}
			System.out.println("  ");
			dan--;
		
	}

}
