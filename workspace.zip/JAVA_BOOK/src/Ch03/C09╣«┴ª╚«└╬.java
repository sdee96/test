package Ch03;

public class C09문제확인 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double var1 = 3.5;
		double var2 = 2.7;
		
		int result = int(var1 + var2);
		
		
	}

}
