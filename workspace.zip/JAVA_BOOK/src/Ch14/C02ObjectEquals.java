package Ch14;


class C02Simple{
	int n;
	C02Simple(int n){
		this.n = n;
		
	}
	@Override
	//equals 재정의 주소값이 아닌 C02Simple 안의 n값을 비교하겠다
	public boolean equals(Object obj) {
		if(obj instanceof C02Simple) {
			C02Simple down = (C02Simple)obj; // downcasting
			return this.n==down.n;
		}
		return false;
		
	}
}

public class C02ObjectEquals {

	public static void main(String[] args) {
		C02Simple ob1 = new C02Simple(10);
		C02Simple ob2 = new C02Simple(10);
		C02Simple ob3 = new C02Simple(20);
		
		System.out.println(ob1.equals(ob2)); //주소값 비교
		System.out.println(ob1.equals(ob3));
		
		String str1 = new String("JAVA");
		String str2 = new String("JAVA");
		str1.equals(str2);

	}

}
