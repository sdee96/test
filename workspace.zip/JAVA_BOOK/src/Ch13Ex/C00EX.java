package Ch13Ex;


class A{
	private int a;
	public void set(int a) {
		this.a = a;
		
	}
}
class B extends A{
	protected int b,c;
	
}
class c extends B{
	public int d,e;
}

public class C00EX {

	public static void main(String[] args) {
		
		
		A objA = new A();

	}

}
