package Ch02;

public class c06실수오차범위 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Float :" +(0.55555555555F)); // 반올림 처리
		System.out.println("Double :" +(0.77777777777777));
		System.out.println("Double :"+(0.222222222222222222));
	}

}
