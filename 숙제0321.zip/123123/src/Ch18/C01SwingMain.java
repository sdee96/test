package Ch18;

import javax.swing.JFrame;

public class C01SwingMain {

	public static void main(String[] args) {
			JFrame frame = new JFrame("첫번째 프레임입니다"); // 창 제목
			frame.setBounds(100,00,500,500);  //   x,   y  , width , height
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //X버튼을  눌렀을 때 종료
			frame.setVisible(true);

	}

}
