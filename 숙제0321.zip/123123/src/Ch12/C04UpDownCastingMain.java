package Ch12;

//자동 형변환되며 부모 클래스로 형변환

class Super{
	int n1;
	
}
class Sub extends Super{
	
	int n2;
	
}
public class C04UpDownCastingMain {

	public static void main(String[] args) {
	
		//no casting
		Super ob1 = new Super();
		ob1.n1 = 10;
		Sub ob2= new Sub();
		ob2.n1 = 10;
		ob2.n2 = 20;
		
		
		//UpCasting : 상위클래스참조변수 = 하위클래스객체
		//UpCasting은 상위 클래스 형으로 형변환을 하는 문법
		//UpCasting은 자동형변환이 된다
		Super ob3 = new Sub(); // 상위 클래스의 참조변수로 하위클래스 연결
		ob3.n1 = 100;
//		ob3.n2 = 200;
		
		//DownCasting : 하위 클래스 참조변수로  = 상위 클래스 형 객체
		//DownCasting : 하위 클래스형으로 형변환을 시도하는 문법
		//DownCasting : 강제형변환을 한다
		//DownCasting은 Upcasting을 선행한뒤 downcasting을 해야한다 
		Sub ob4 = (Sub)ob3; // ob3은 위에서 super로 형변환이 된 상태 왼쪽 Sub로 강제 형변환을 해줘야함
		ob4.n1=10;
		ob4.n2=200;
		
		

	}

}
