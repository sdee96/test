package Ch08;



class TV{
	String brand ;
	int year ;           //속성추가
	int inch ;
	
	TV(String brand , int year , int inch){
		this.brand = brand;
		this.year = year;
		this.inch = inch;
		
	}
	
	
	void showinfo() {
			System.out.println(this.brand+"에서 만든"+this.year+"년형"+this.inch+"형 TV입니다");
			
			
}
}

public class C00ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 TV mytv = new TV("LG",2017,32);
	 mytv.showinfo();
	

	}

	
}
