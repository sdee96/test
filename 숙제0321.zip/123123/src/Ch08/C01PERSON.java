package Ch08;

public class C01PERSON {
	//속성
	String name;
	int age;
	float height;
	double weight;
	

	
	//기능
}
