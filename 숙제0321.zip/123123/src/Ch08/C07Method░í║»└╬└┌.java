package Ch08;

class Simple07{
	int sum(int ...arg) {
//		System.out.println(arg);
		for(int num :arg) {
			System.out.print(num + " ");
		}
		return 0;
	}
	 
}
	//가변인자 vs 오버로딩
	//공통점 : 함수이름을 같게할 수 있음
	//차이점 : 

 
public class C07Method가변인자 {

	public static void main(String[] args) {
		Simple07 obj = new Simple07();
		obj.sum(10);
		System.out.println();
		obj.sum(10,11);
		System.out.println();
		obj.sum(10,11,33);
		System.out.println();

	}

}
