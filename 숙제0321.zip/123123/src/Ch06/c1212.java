package Ch06;

public class c1212 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner sc = new Scanner(System.in);
		int menu=0;
		//
		
		while(true) {
			
			System.out.println("--menu--");
			System.out.println("1 도서조회");
			System.out.println("2 도서 등록");
			System.out.println("3 도서 수정");
			System.out.println("4 도서 삭제");
			System.out.println("종료");
			menu = sc.nextInt();
			switch(menu) {
			case 1:
				System.out.println("도서조회");
				//조회
				break;
			
			case 2:
				System.out.println("도서조회");
				//등록
				break;
			case 3: 
				//수정
				System.out.println("도서조회");
				break;
			
			case 4:
				//삭제
				System.out.println("도서조회");
				break;
				
			case 5:
				//종료
				System.out.println("도서조회");
				System.exit(-1);
				
			default :
			 System.out.println("오입력");
		}
				

	}

}
