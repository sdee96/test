package Ch06;

import java.util.Scanner;

public class c08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 ;
		int num2 ;
		int num3 ;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("정수입력");
		num1 = sc.nextInt();
		
		System.out.println("정수 입력");
		num2= sc.nextInt();
		System.out.println("정수 입력");
		num3= sc.nextInt();
		
		
		System.out.println("이 세 수의 평균은 :"+((double)num1+num2+num3)/3);
		
		
		int n1;
		int n2;
		int n3;
		
		n1= sc.nextInt();
		n2= sc.nextInt();
		n3= sc.nextInt();
		
		if(n1>=n2&&n1>=n3) {
			System.out.println("큰수 : " +n1);
		}
		else if(n2>=n1&n2>=n3) {
			System.out.println("큰수 : "+n2);
			
			if(n2>n1) {
				
			}
		}
		
		

		
		

	}

}
