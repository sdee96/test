package Ch14;

public class C00INFO {
	//
}
