package Ch13;
//일반클래스 상속관계
class Super1{
	void Func() {};
	
	
}
class Son1 extends Super1{
	
	void Func() {System.out.println("Son1's Function");}
	
}
//추상 클래스 상속관계
abstract class Super2{
	abstract void Func();
}


class Son2 extends Super2{

	@Override
	void Func() {System.out.println("Son2's Function");
		
		System.out.println();
		// TODO Auto-generated method stub
		
	}
	
}

public class C01AbstractMain {

	public static void main(String[] args) {
		//01
//		Super1 ob1 = new Super1(); //상위클래스 객체 생성 o		
//		Son1 ob2= new Son1();		
//		ob1.Func();                // 상위 클래스에서  하위클래스가 추가된 메서드 접근 X
//									// 상위클래스에서 정의한 메서드를 하위클래스에서 재정의한 경우 접근 O
//	
//
//			Super1 ob3 = ob2;
//			ob3.Func();
		
		
//		Super2 ob = new Super2();  //오류
		
		Son2 ob2 = new Son2();
		
		Super2 ob3= ob2;  // upcasting O
		
		ob3.Func();
		

	}

}
