package Ch19;

import java.io.BufferedInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.Writer;
import java.net.URL;

public class C09URLStreamMain {

	public static void main(String[] args)throws Exception {
		
		URL url = new URL("https://n.news.naver.com/mnews/article/417/0000990148");
		InputStream bin = url.openStream();
		
		BufferedInputStream buffin = new BufferedInputStream(bin); //보조 스트림
																   //버퍼공간 주기
		
		Reader in =new InputStreamReader(buffin);
		
		
		Writer wout=new FileWriter("c:\\tmp_io\\index.html");
		while(true) {
			int data= in.read();
			if(data==-1)
				break;
			wout.write((char)data);
		}
	}

}
