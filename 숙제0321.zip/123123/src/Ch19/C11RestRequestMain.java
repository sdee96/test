package Ch19;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;

import com.fasterxml.jackson.databind.ObjectMapper;

public class C11RestRequestMain {

	public static void main(String[] args)throws Exception {
		
			String mode ="json";
			String addr ="중구";
			String url = "https://www.daegufood.go.kr/kor/api/tasty.html";
			
			url = url+"?"+"mode="+mode+"&addr="+addr;
			
			
			
			
			//HTTP 요청 단위 생성
			HttpRequest httpRequest=HttpRequest.newBuilder()
									.uri(URI.create(url))
									.GET()
									.build();
			
			
			//HTTP 요청
			HttpClient httpClient = HttpClient.newHttpClient();
			HttpResponse<String> response = httpClient.send(httpRequest,HttpResponse.BodyHandlers.ofString());
			System.out.println(response.body());
			
			//STRING -> Class 변환
			ObjectMapper objectMapper = new ObjectMapper();
			
			Root responseData =objectMapper.readValue(response.body(), Root.class);
			
			System.out.println(responseData.getData().get(0).getMNU());
			
			
	}

}
//import com.fasterxml.jackson.databind.ObjectMapper; // version 2.11.1
//import com.fasterxml.jackson.annotation.JsonProperty; // version 2.11.1
/* ObjectMapper om = new ObjectMapper();
Root root = om.readValue(myJsonString, Root.class); */
class Datum{
 public String Cnt;
 public String OPENDATA_ID;
 public String GNG_CS;
 public String FD_CS;
 public String BZ_NM;
 
 public String TLNO;
 public String MBZ_HR;
 public String SEAT_CNT;
 public String PKPL;
 public String HP;
 public String PSB_FRN;

 public String BKN_YN;
 public String INFN_FCL;
 public String BRFT_YN;
 public String DSSRT_YN;
 public String MNU;
 public String SMPL_DESC;
 public String SBW;
 public String BUS;
/**
 * @return the cnt
 */
public String getCnt() {
	return Cnt;
}
/**
 * @param cnt the cnt to set
 */
public void setCnt(String cnt) {
	Cnt = cnt;
}
/**
 * @return the oPENDATA_ID
 */
public String getOPENDATA_ID() {
	return OPENDATA_ID;
}
/**
 * @param oPENDATA_ID the oPENDATA_ID to set
 */
public void setOPENDATA_ID(String oPENDATA_ID) {
	OPENDATA_ID = oPENDATA_ID;
}
/**
 * @return the gNG_CS
 */
public String getGNG_CS() {
	return GNG_CS;
}
/**
 * @param gNG_CS the gNG_CS to set
 */
public void setGNG_CS(String gNG_CS) {
	GNG_CS = gNG_CS;
}
/**
 * @return the fD_CS
 */
public String getFD_CS() {
	return FD_CS;
}
/**
 * @param fD_CS the fD_CS to set
 */
public void setFD_CS(String fD_CS) {
	FD_CS = fD_CS;
}
/**
 * @return the bZ_NM
 */
public String getBZ_NM() {
	return BZ_NM;
}
/**
 * @param bZ_NM the bZ_NM to set
 */
public void setBZ_NM(String bZ_NM) {
	BZ_NM = bZ_NM;
}
/**
 * @return the tLNO
 */
public String getTLNO() {
	return TLNO;
}
/**
 * @param tLNO the tLNO to set
 */
public void setTLNO(String tLNO) {
	TLNO = tLNO;
}
/**
 * @return the mBZ_HR
 */
public String getMBZ_HR() {
	return MBZ_HR;
}
/**
 * @param mBZ_HR the mBZ_HR to set
 */
public void setMBZ_HR(String mBZ_HR) {
	MBZ_HR = mBZ_HR;
}
/**
 * @return the sEAT_CNT
 */
public String getSEAT_CNT() {
	return SEAT_CNT;
}
/**
 * @param sEAT_CNT the sEAT_CNT to set
 */
public void setSEAT_CNT(String sEAT_CNT) {
	SEAT_CNT = sEAT_CNT;
}
/**
 * @return the pKPL
 */
public String getPKPL() {
	return PKPL;
}
/**
 * @param pKPL the pKPL to set
 */
public void setPKPL(String pKPL) {
	PKPL = pKPL;
}
/**
 * @return the hP
 */
public String getHP() {
	return HP;
}
/**
 * @param hP the hP to set
 */
public void setHP(String hP) {
	HP = hP;
}
/**
 * @return the pSB_FRN
 */
public String getPSB_FRN() {
	return PSB_FRN;
}
/**
 * @param pSB_FRN the pSB_FRN to set
 */
public void setPSB_FRN(String pSB_FRN) {
	PSB_FRN = pSB_FRN;
}
/**
 * @return the bKN_YN
 */
public String getBKN_YN() {
	return BKN_YN;
}
/**
 * @param bKN_YN the bKN_YN to set
 */
public void setBKN_YN(String bKN_YN) {
	BKN_YN = bKN_YN;
}
/**
 * @return the iNFN_FCL
 */
public String getINFN_FCL() {
	return INFN_FCL;
}
/**
 * @param iNFN_FCL the iNFN_FCL to set
 */
public void setINFN_FCL(String iNFN_FCL) {
	INFN_FCL = iNFN_FCL;
}
/**
 * @return the bRFT_YN
 */
public String getBRFT_YN() {
	return BRFT_YN;
}
/**
 * @param bRFT_YN the bRFT_YN to set
 */
public void setBRFT_YN(String bRFT_YN) {
	BRFT_YN = bRFT_YN;
}
/**
 * @return the dSSRT_YN
 */
public String getDSSRT_YN() {
	return DSSRT_YN;
}
/**
 * @param dSSRT_YN the dSSRT_YN to set
 */
public void setDSSRT_YN(String dSSRT_YN) {
	DSSRT_YN = dSSRT_YN;
}
/**
 * @return the mNU
 */
public String getMNU() {
	return MNU;
}
/**
 * @param mNU the mNU to set
 */
public void setMNU(String mNU) {
	MNU = mNU;
}
/**
 * @return the sMPL_DESC
 */
public String getSMPL_DESC() {
	return SMPL_DESC;
}
/**
 * @param sMPL_DESC the sMPL_DESC to set
 */
public void setSMPL_DESC(String sMPL_DESC) {
	SMPL_DESC = sMPL_DESC;
}
/**
 * @return the sBW
 */
public String getSBW() {
	return SBW;
}
/**
 * @param sBW the sBW to set
 */
public void setSBW(String sBW) {
	SBW = sBW;
}
/**
 * @return the bUS
 */
public String getBUS() {
	return BUS;
}
/**
 * @param bUS the bUS to set
 */
public void setBUS(String bUS) {
	BUS = bUS;
}
 
 
 
 
 
}

class Root{
 public String status;
 public String total;
 public ArrayList<Datum> data;
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getTotal() {
	return total;
}
public void setTotal(String total) {
	this.total = total;
}
public ArrayList<Datum> getData() {
	return data;
}
public void setData(ArrayList<Datum> data) {
	this.data = data;
}
 
 
}

