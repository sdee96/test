package Ch13Ex;


class TV{
	private int size;
	public TV(int size) {
		this.size=size;
	}
	protected int getSize() {return size;}
}


class ColorTV extends TV{
	int color;
	public ColorTV(int size,int color) {
		super(size);
		this.color=color;
	
	}
	
	public void printProperty(){
	
//		this.getSize();
		System.out.println(getSize() + "인치" + color + "컬러");
		
	
		
	}
	
}
class IPTV extends ColorTV{
	String ip;

	public IPTV(String ip,int size, int color) {
		super(size, color);
		this.ip=ip;		
	
			
	}
	public void printPropety() {
		
		System.out.println("나의 IPTV는"+this.ip +"주소의" + getSize()+"인치" +color + "컬러");
//		super.printProperty(); // ColorTV의 프로펄티 
	}
	}




public class C00ex0501 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ColorTV myTV = new ColorTV(32,1024);
		myTV.printProperty(); //32인치 1024컬러 문제1
		
		IPTV iptv = new IPTV("192.1.1.2",32,2048);
		iptv.printPropety(); // 1921.1.2.2 32인치 2048 문제2
		
	}

}
