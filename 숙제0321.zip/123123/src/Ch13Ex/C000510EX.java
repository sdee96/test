package Ch13Ex;


abstract class OddDetector{
	protected int n;
	public OddDetector (int n) {
		this.n=n;
	}
	public abstract boolean isOdd();

public class B extends OddDetector{
	public B(int n) {
		super(n);
	}
}
		
	}; // 홀수이면 true 리턴



public class C000510EX {

	public static void main(String[] args) {
		
		
	}

}
