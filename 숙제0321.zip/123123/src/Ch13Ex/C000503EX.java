package Ch13Ex;

class pen{
	private int amount;       //양 속성 추가
	public int getAmount() {   // 양 구하는 속성 추가
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
class Sharp extends pen{
	private int width;  //pen의 속성들 물려받음 나머지 중첩된것 생략 가능
}
	
}
class ball extends pen{
	private String color;          //ball펜에만 컬러속성 있으니 볼펜에서 color 추
	public String getColor() {return color;}
	public void setColor(String color) {
		this.color=color;
	}
	
class Foun extends ball{
	
	public void refill(int n) {setAmount(n);} // 만년필에서도 color속성을 추가해야하나 앞선 ball에서 
											// 속성들을 물려받아 생략가능

	
}
}
public class C000503EX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
	}

}
