package Ch11;


class C02Simple{
	int n1;
	static int n2;
	
	void func1() {
		n1=10;
		n2=20;
	}
	
	static void func2() {
		//n1=400;
		n2=30;
	}
}

public class C02StaticMain {

	public static void main(String[] args) {
		
	}

}
