package Ch08;

public class C01main {

	public static void main(String[] args) {
		C01PERSON hong = new C01PERSON();
		hong.name = "홍길동";
		hong.age = 55;
		hong.height = 177.5f;
		hong.weight =70.4;
		System.out.printf("%s %d %f %f\n",hong.name,hong.age,hong.height,hong.weight);;

		
		//생성자 함수를 만들지 않더라도 default가 만들어짐
		//생성자 함수를 통해 heap영역에 공간이 만들어짐

	}

}
