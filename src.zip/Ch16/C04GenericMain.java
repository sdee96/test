package Ch16;

class C04Animal{
	
}

class Tiger extends C04Animal{
	String name;
	//생성자

	public Tiger(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Tiger [name=" + name + "]";
	}
	
	//toString
	
}
class Panda extends C04Animal{
	String name;
	//생성자
	public Panda(String name) {
		super();
		this.name = name;
	}
	//toString
	@Override
	public String toString() {
		return "Panda [name=" + name + "]";
	}
	
	
	
	
	
}

public class C04GenericMain {
	
	//generic	 다운캐스팅을 필요로 하지 않음
	public static <T extends C04Animal>void PirntInfo(T[] arr) {
		for(T el : arr)
			System.out.println(el);
		
	}
	//object 
	public static void PirntInfo2(Object[] arr) {
		for(Object el : arr) {
			System.out.println(el);
			if(el instanceof Tiger) {
				Tiger down = (Tiger)el;
				
			}
		}
		
	}

	public static void main(String[] args) {
		Tiger[] arr = {new Tiger("시베리안호랑이"),new Tiger("호랭이")
				,new Tiger("호호호")};
		PirntInfo(arr);
		Panda[] arr2 = {new Panda("중국팬더"),new Panda("랫서팬더")};
		PirntInfo(arr2);
		Object[] arr3 = {new Tiger("호랭랭"),new Panda("팬더임")};
//		PrintInfo(arr3);
		
		PirntInfo2(arr3);
		
		
	}

}
