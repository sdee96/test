package Ch15;

public class C04문제 {
	
	//명품자바 4장 클래스 기본
	//https://security-nanglam.tistory.com/212
	
	//명품자바 5장 상속
	//https://security-nanglam.tistory.com/215
	
}
