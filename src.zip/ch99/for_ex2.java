package ch99;

import java.util.Scanner;

public class for_ex2 {

	public static void main(String[] args) {
		for(int i=1; i<6; i++) {
			
			//첫 줄
			if(i>=4) {
				for(int a=1; a<6-i; a++) {
					System.out.print("☆");
				}
			}
			else {
				for(int a=1; a<i; a++) {
					System.out.print("☆");
				}
			}
			//둘 째 줄
			System.out.print("★");
			//셋 째 줄
			if(i<=2) {
				for(int a=1; a<6-2*i; a++) {
					System.out.print("☆");
				}
				
			}
			else if(i==3) {
				System.out.print("☆☆");
			
			}
			else {
				for(int a=1; a<2*i-6; a++) {
					System.out.print("☆");
				}
			}
			//넷째 줄\
			if(i==3) {
				System.out.print(" ");
			}else {
				System.out.print("★");
			}
			
			//다섯쨰 줄
			if(i%2==1) {
				System.out.print(" ");
				
			}else {
				System.out.print("☆");
			}
			System.out.println();
			
		}
	
		
	}

}
