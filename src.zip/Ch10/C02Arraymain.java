package Ch10;

import java.util.Arrays;

public class C02Arraymain {

	public static void main(String[] args) {
		//얕은복사 위치 값을 당겨온다?
		int arr1[]= {10,20,30};
		int arr2[];
		arr2=arr1;
		arr1[0]=100;  // 대입연산은 복사 X 위치를 공유
		
		for(int val : arr2) {
			System.out.println(val + " ");
		}
		System.out.println();
		
		//깊은복사
		int arr3[]=new int[3]; // 똑같은 구조를 가진 배열을 만든 후
		
		for(int i = 0; i<arr3.length;i++) {
			arr3[i] = arr1[i];
			
		}
		int arr4[] = Arrays.copyOf(arr1,arr1.length);
		
		System.out.println("arr 1  : " + arr1);
		System.out.println("arr 4  : " + arr4);
		
		for(int val : arr4) 
			System.out.println(val);
		
		
	}

}
