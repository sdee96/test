package Ch07;

import java.util.Scanner;

public class C00whiletest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//문제
				//N,M 을 입력받아서 N부터 M 까지의 수N<M)
		Scanner sc = new Scanner(System.in);
		int n;
		int m;
		
		
		System.out.println("수 입력");
		n=sc.nextInt();
		System.out.println("그 다음 수 입력");
		m=sc.nextInt();
		
		
		
		while(n<=m) {
			
			System.out.println("n :"+ n );
			
			
			n++;
		
			
							
			
			
		}
		
		int q =sc.nextInt();
		int w =sc.nextInt();
		if(q>w) 
		{ 
			
			
			int tmp=q;
			q=w;
			w=tmp;
			
			
		}
		int i=q;
		int sum=0;
		while(q>w){
									
			sum=+i;
			i++;
						
			
		}
		System.out.printf("%d 부터 %d까지의 합 : %d\n",q,w,sum);

	

	}

}
