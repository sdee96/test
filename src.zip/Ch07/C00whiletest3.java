package Ch07;

public class C00whiletest3 {

}
