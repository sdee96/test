package Ch17;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

public class C02EX {

	public static void main(String[] args) throws InterruptedException {
		//1 ~ 45 까지 숫자를 6개를 랜덤으로 받아(Random 클래스 이용) set에 저장
		//[추가]저장된 set의 오름차순정렬 
		
		Set<Integer> set = new HashSet();
		Random rnd = new Random();
		
//		while(true) {
//			
//			if(set.size()==6) //.size = 개수 확인 6개를 받으므로 set.size()==6
//			{
//				break;    // 6개를 받은 후 반복을 멈춤
//			}
//			System.out.println(rnd.nextInt(44)+1);
//			set.add(rnd.nextInt(44)+1);
//					
		while(set.size()<=6) {
			set.add(rnd.nextInt(44)+1);
		}
//			
//		List<Integer> list = new ArrayList(set);
//		Collections.sort(list);
//		for(int num : list) {
//			System.out.println(num  +  " ");
//		}
		
		//Collection's Stream
		List<Integer> list = 
				set.stream()
				.sorted()
				.collect(Collectors.toList());
		for(int n :list)System.out.println(n + " ");
				
		
		
		}
	
					
	}


