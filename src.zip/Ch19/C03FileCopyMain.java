package Ch19;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;

public class C03FileCopyMain {

	private static String Filedir = "c:\\tmp_io\\";
	public static void main(String[] args) throws Exception{
		
		for(String arg : args)
			System.out.println(arg);
		
		
		Reader in = new FileReader(Filedir+args[0]);
		Writer out = new FileWriter(Filedir+args[1]);
		
		while(true) {
			int data = in.read();
			if(data==-1)
				break;
			out.write((char)data);
			out.flush();
		}
		in.close();
		out.close();
		

	}

}
