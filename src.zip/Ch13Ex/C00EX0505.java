package Ch13Ex;

class Point{
	private int x,y;
	public Point(int x,int y) {
		this.x=x;
		this.y=y;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	protected void move(int x,int y) {
		this.x=x;
		this.y=y;
	}
	
}

//class ColorPoint extends Point{
//	String Color;
//	
//
//	public ColorPoint(int x, int y,String Color) {
//		super(x, y);
//		
//	}
//	public void setXY(int x,int y) {
//	move(x,y);
//		
//	}
//	public String SetColor(String color) {
//		this.Color=color;
//		return color;
//	}
//	@Override
//	public String toString() {
//		return Color+"색의"+"("+getX()+","+getY()+")의 점";
//	}
//	
//}

class ColorPoint extends Point{
	String Color;
	public ColorPoint() {
		super(0,0);
		this.Color="BLACK";
		
	}
	
	public ColorPoint(int x,int y) {
		super(x,y);
		
	}
	public void setXY(int x,int y) {
		move(x,y);
	}
	
	public String SetColor(String color) {
	this.Color=color;
		return color;
	}
	




	

	

	@Override
	public String toString() {
		return "123";
	
	
}
}
class Point3D extends Point{

	public Point3D(int x, int y) {
		super(x, y);
			}
	
	
}

public class C00EX0505 {

	public static void main(String[] args) {
////		ColorPoint cp = new ColorPoint(5,5,"YELLOW");
//		cp.setXY(10,20);
//		cp.SetColor("RED");
//		String str = cp.toString();
//		System.out.println(str+"입니다");
		
		ColorPoint zero = new ColorPoint();
	

	}

}
