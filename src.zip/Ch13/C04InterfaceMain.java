package Ch13;


interface A{}
interface B{}


class C implements A,B{}


public class C04InterfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
