package Ch13;

interface Remocon{
	int MAXVOL=100;
	int MINVOL=0;
	void On();
	void Off();
	void setVolume(int vol);
	
}
interface Browser{
	void SearchURL(String url);
}


class TV implements Remocon{
	
	private int vol;

	@Override
	public void On() {
		System.out.println("TV켬");
		
		
	}

	@Override
	public void Off() {
		System.out.println("TV끔");
		
	}

	@Override
	public void setVolume(int vol) {
		if(vol>=MAXVOL) {
			this.vol=MAXVOL;
		}else if(vol<=MINVOL) {
			this.vol=MINVOL;
		}else
			this.vol=vol;
		System.out.println("현재 TV볼륨 : " + this.vol);
		
		
	}
	
}
class Radio implements Remocon{
	private int vol;
	

	@Override
	public void On() {
		System.out.println("Radio켬");
	
		
	}

	@Override
	public void Off() {
		System.out.println("Radio끔");
		
	}

	@Override
	public void setVolume(int vol) {
		if(vol>=MAXVOL) {
			this.vol=MAXVOL;
		}else if(vol<=MINVOL) {
			this.vol=MINVOL;
		}else
			this.vol=vol;
		System.out.println("현재 라디오볼륨 : " + this.vol);
		
	}
	
	
}
class SmartTV extends TV implements Browser{
	
	@Override
	public void SearchURL(String url) {
		System.out.println(url + " 로 이동");
		
	}
	
}
	
public class C02Interfacemain {
	public static void TurnOn(Remocon remocon){
		remocon.On();
	}
	public static void TurnOff(Remocon remocon){
		remocon.Off();
	}
	
	public static void Volume(Remocon remocon,int vol) {
		remocon.setVolume(vol);
	}
	public static void BrowserSearch(Browser searchurl1,String url) {
		searchurl1.SearchURL(url);
	}
	
	
	public static void main(String[] args) {
		TV tv1= new TV();
		Radio radio1 = new Radio();
		
		SmartTV smartTv = new SmartTV();
		
		TurnOn(smartTv);
		Volume(smartTv,10);
		BrowserSearch()
		
//		TurnOn(tv1);
//		TurnOn(radio1);
//		
//		Volume(tv1,10);
//		Volume(radio1,100);
//		TurnOff(tv1);
//		TurnOff(radio1);
//		

	}

}
