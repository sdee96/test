package Ch18;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class C006EX extends JFrame implements ActionListener,KeyListener,MouseListener{
	JButton btn1;
	JButton btn2;
	JButton btn3;
	JButton btn4;
	
	JTextField txt1;
	JTextField txt2;
	JTextArea area1;
	JScrollPane scroll1;
	C006EX(){
		super("Chatting Server");
		setBounds(100,100,500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Panel 생성
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		
		
		
		
		//Btn_component 추가
		btn1 = new JButton("파일로 저장");
		btn1.setBounds(350,30,120,40);
		
		btn2 = new JButton("1:1요청");
		btn2.setBounds(350,80,120,40);
		
		btn3 = new JButton("대화기록 보기");
		btn3.setBounds(350,130,120,40);
		
		btn4 = new JButton("입력");
		btn4.setBounds(350,380,120,40);
		
		
		
		//Text Field 추가
		txt1 = new JTextField();
		txt1.setBounds(10,380,300,40);
		
		
		//Text Area추가 
		area1 =new JTextArea();
		area1.setBounds(10,10,300,350);
		
		
		//ScrollPanel_component 추가
		scroll1 = new JScrollPane(area1);
		scroll1.setBounds(10,10,300,350);
		
		//Event에 Component 추가
		txt1.addKeyListener(this);
//		btn3.addMouseListener(this);	
		btn4.addMouseListener(this);	
			
		
		
		
		//Component Panel에 추가
		panel.add(btn1);
		panel.add(btn2);
		panel.add(btn3);
		panel.add(btn4);
		panel.add(txt1);
		
		panel.add(scroll1);
		
		
		
		//frame에 panel 추가
			add(panel);				
			setVisible(true);
		
		
		
		
		
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==btn4) {
		String message = txt1.getText();
		area1.append(message+"\n");
		txt1.setText("");}
		if(e.getSource()==btn3) {
			System.out.println("btn3 clicked");
		}
		
		
		
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getSource()==txt1) {
			if(e.getKeyCode()==10) {
				String message = txt1.getText();
				area1.append(message+"\n");
				txt1.setText("");
			}
		}
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		
		}
	}
	


public class C06EX {

	public static void main(String[] args) {
		
		
		new C006EX();
	}

}
