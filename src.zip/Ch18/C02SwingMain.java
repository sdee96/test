package Ch18;

import javax.swing.JFrame;

class C02GUI extends JFrame{
	C02GUI(){
		super("두번 째 프레임 입니다"); // JFrame의 생성자를 호출
		setBounds(100,00,500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
}

public class C02SwingMain {

	public static void main(String[] args) {
		
		new C02GUI();

	}

}
