/**
 * 
 */
/**
 * 
 */
module JAVA_BOOK {
	requires java.desktop;
}