package ch99;

public class for_ex {
public static void main(String[] args) {
	
	for(int i = 1; 1<6; i++) {
		//첫줄
		if(i>=4) { 
			for(int a =1; a<6-i; a++) {
				System.out.println("☆");
			}
		}
		else {
			for(int a =1 ; a<i; a++) {
				System.out.println("☆");
			}
		}
		//둘쨰줄
		System.out.println("★");
		
		
		//셋째 줄
		if(i<=2) {
			for(int a =1 ; a <6-2*i; a++) {
				System.out.println("☆");
			}
		}
		else if(i==3) {
			System.out.println("☆☆");
		}
		else {
			for(int a=1; a<2*i-6; a++) {
				System.out.println("☆");
			}
		}
		
		//넷째 줄 
		if(i==3) {
			System.out.println(" ");
		}else {
			System.out.println("★");
		}
		
		//다섯째
		if(i%2==1) {
			System.out.println(" ");
			
		}else {
			System.out.println("☆");
		}
		
		
		System.out.println();
		}
		
		
	}
	
	
	
}

