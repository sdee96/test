package contorller;

import java.util.HashMap;
import java.util.Map;

import domain.dto.UserDto;
import service.UserServiceImpl;

public class UserController implements SubController{
	
	private UserServiceImpl userService;
	
	public UserController() {
		try {
			userService=UserServiceImpl.getInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//1 회원가입 , 2 업데이트 3 삭제 4 전체조회 5조회 6로그인 7 로그아웃
	
	public Map<String,Object> execute(int serviceNo,Map<String,Object> params){
		System.out.println("UserController's execute()");
		if(serviceNo==1) {
			//파라미터
			UserDto dto= (UserDto) params.get("userDto");
			
			//유효성
			if(!isValid(dto)) {
				return null;
			}
			//서비스
			boolean isJoined = false;
			try {
				isJoined =userService.UserJoin(dto);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Map<String,Object> result = new HashMap();
			result.put("response", isJoined);
			
		}else if(serviceNo==2) {
			System.out.println("업데이트 시도");
			UserDto dto = (UserDto) params.get("userDto");
			if(!isValid(dto)) {
				return null;
			}
			boolean isUpdated = false;
			try {
				
				isUpdated = userService.UserUpdate(dto);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}else if(serviceNo==3) {
			//삭제
			HashMap map =(HashMap) params.get("UserDto");
			Integer id = (Integer) map.get("user_id");
			String password  = (String) map.get("passsword");
			
			
			
			try {
				userService.UserDelete(id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}else if(serviceNo==4) {
			
			
			
		}else if(serviceNo==5) {
			//조회
			//파라미터
			String id = (String) params.get("UserDto");
			userService.se
			
			
		}else if(serviceNo==6) {
			//서비스6 로그인
			
			//파라미터
			String username = (String) params.get("username");
			String password = (String) params.get("password");
			Integer sessionId= (Integer) params.get("sessionId");
			//
			if(!isValid(username,password,sessionId)) {
				return null;
			}
			
			
		}else if(serviceNo==7) {
			//파라미터 받기
			Integer sessionId = (Integer) params.get("sessionId");
			//유효성 체크
			Map<String,Object> response = null;
			if(isValid(sessionId)) {
				response = new HashMap();
				response.put("response", false);
				response.put("msg", "유효성 체크 에러");
				return response;
			}
			try {
				response = userService.logout(sessionId);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return response;
			
		}else {
			
		}
			
			return null;
		}

	private boolean isValid(Integer sessionId) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean isValid(String username, String password, Integer sessionId) {
		// TODO Auto-generated method stub
		return true;
	}

	private boolean isValid(UserDto dto) {
		// TODO Auto-generated method stub
		return true;
	
		
	}
	
	

}
