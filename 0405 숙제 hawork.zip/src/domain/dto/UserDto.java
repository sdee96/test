package domain.dto;

public class UserDto {
	
	private int user_id;
	private String password;
	private String name;
	private int phone_number;
	private String email;
	private String role;
	@Override
	public String toString() {
		return "UserDto [user_id=" + user_id + ", password=" + password + ", name=" + name + ", phone_number="
				+ phone_number + ", email=" + email + ", role=" + role + "]";
	}
	public UserDto(int user_id, String password, String name, int phone_number, String email, String role) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.name = name;
		this.phone_number = phone_number;
		this.email = email;
		this.role = role;
	}
	
	public UserDto() {}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	};


	
	
	
}
