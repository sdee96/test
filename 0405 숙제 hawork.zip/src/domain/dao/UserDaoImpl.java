package domain.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import domain.dto.UserDto;

public class UserDaoImpl extends CommonDao {
	
	private static UserDaoImpl instance;
	public static UserDaoImpl getInstance() throws Exception {
		if(instance==null)
			instance =new UserDaoImpl();
		return instance;
		
	}
	
	
	
	public UserDaoImpl() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		System.out.println("[DAO] UserDaoImpl's INIT DB Connected...");
	}
	//INSERT
	public boolean Insert(UserDto dto) throws Exception{
		pstmt=conn.prepareStatement("insert into user values(?,?,?,?,?,?)");
		pstmt.setInt(1, dto.getUser_id());
		pstmt.setString(2,dto.getPassword());
		pstmt.setString(3, dto.getName());
		pstmt.setInt(4, dto.getPhone_number());
		pstmt.setString(5, dto.getEmail());
		pstmt.setString(6, dto.getRole());
		
		return pstmt.executeUpdate()>0;
	}
	
	//select 
	public UserDto Select(int user_id) throws Exception{
		pstmt=conn.prepareStatement("select *from user where  user_id=?");
		pstmt.setInt(1, user_id);
		rs=pstmt.executeQuery();
		UserDto dto=null;
		
		if(rs!=null) {
			if(rs.next()) {
				dto=new UserDto();
				dto.setUser_id(rs.getInt(user_id));
															
				dto.setName(rs.getString("name"));
				dto.setPassword(rs.getString("password"));
				dto.setPhone_number(rs.getInt("phone_number"));
				dto.setEmail(rs.getString("email"));
				dto.setRole(rs.getString("member"));
			}
		}
		return dto;
	}
	//delete
	public boolean Delete(int user_id) throws Exception{
		pstmt=conn.prepareStatement("delete from user where user_id=?");
		pstmt.setInt(1, user_id);
		
		return pstmt.executeUpdate()>0;
	}
	public List<UserDto> SelectAll() throws Exception{
		List<UserDto> userlist = new ArrayList();
		pstmt=conn.prepareStatement("select *from user");
		rs=pstmt.executeQuery();
		if(rs!=null) {
			while(rs.next()) {
				UserDto dto =new UserDto();
				dto.setUser_id(rs.getInt("user_id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setPhone_number(rs.getInt("phone_number"));
				dto.setEmail(rs.getString("email"));
				dto.setRole(rs.getString("member"));
				
				userlist.add(dto);
				System.out.println(dto);
			}
		}
			else
				System.out.println("조회실패했음");
			rs.close();
			pstmt.close();
			return userlist;
		}
	//update
	public boolean update(UserDto dto) throws Exception{
		pstmt=conn.prepareStatement("update user set password=?,name=?,phone_number=?,email=?,member=? where user_id=? ");
		pstmt.setString(1, dto.getPassword());
		pstmt.setString(2, dto.getName());
		pstmt.setInt(3, dto.getPhone_number());
		pstmt.setString(4, dto.getEmail());
		pstmt.setString(5, dto.getRole());
		pstmt.setInt(6, dto.getUser_id());
		
		return pstmt.executeUpdate()>0;
		
		
		
		}
	}
	
	


